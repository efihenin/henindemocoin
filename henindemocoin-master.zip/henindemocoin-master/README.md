HeninDemoCoin (HDC)
===========

[![Build Status](https://travis-ci.org/RazorLove/henindemocoin.png?branch=master)](https://travis-ci.org/RazorLove/henindemocoin)


Scrypt Hashcash PoW Template